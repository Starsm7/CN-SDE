import torch

data_pt = torch.load('data/fate_train.pt')

data_pt['xp'] = data_pt['xp'][::-1]
torch.save(data_pt, 'data/fate_train_fu.pt')

