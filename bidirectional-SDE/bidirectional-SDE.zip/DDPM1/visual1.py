from types import SimpleNamespace
import numpy as np
import torch
import matplotlib.pyplot as plt
from src.model import ForwardSDE


config = SimpleNamespace(**torch.load('RESULTS/seed1/config.pt'))
model = ForwardSDE(config)
model.load_state_dict(torch.load('RESULTS/seed1/train.best.pt')['model_state_dict'])
data_pt = torch.load('data/fate_train_fu.pt')
t = torch.tensor(np.concatenate([np.full(len(xp), i) for i, xp in enumerate(data_pt['xp'])]).reshape(-1, 1)).float()
x = torch.cat(data_pt['xp'])
pot, _ = model._func._pot(t, x, eval_p=True)

# 为什么这里是负号/-1，因为这里是逆向过程，势能函数的趋势是从低势能往高势能学习，所以要×负号

# pot = pot.detach().cpu().numpy()[:, 0][::-1]
pot = torch.mean(pot, dim=1).detach().cpu().numpy()[::-1]
min_p = np.min(pot)
max_p = np.max(pot)
plt.figure(figsize=(10, 5))
plt.plot(pot, label='Potential', color='blue', linewidth=2)
plt.title("Potential over Times")
plt.xlabel("Times")
plt.ylabel("Potential Value")
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()
plt.savefig('potential_line.png', dpi=800)
plt.show()

plt.figure(figsize=(12, 6))
scatter = plt.scatter(
    x=np.arange(len(pot)),  # x轴为索引/步骤
    y=pot,                  # y轴为势能值
    c=pot,                  # 颜色映射到pot值
    cmap='viridis_r',       # 使用反向的viridis色阶（数值越大颜色越深）
    marker='*',             # 星星标记
    s=90,                  # 点大小
    edgecolors='white',     # 边缘白色增强对比
    linewidths=0.01,         # 边缘线宽
    alpha=0.95               # 透明度
)
cbar = plt.colorbar(scatter)
cbar.set_label('Potential Value', rotation=270, labelpad=15)
plt.title("Potential over Times", fontsize=14, pad=20)
plt.xlabel("Times", fontsize=12)
plt.ylabel("Potential Value", fontsize=12)
plt.grid(True, linestyle='--', alpha=0.4)
plt.ylim(min_p - 0.1 * (max_p - min_p), max_p + 0.1 * (max_p - min_p))
plt.savefig('potential_scatter.png', dpi=800, bbox_inches='tight')
plt.show()