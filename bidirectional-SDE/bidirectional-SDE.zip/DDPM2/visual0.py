import os
from types import SimpleNamespace
import numpy as np
import torch
import matplotlib.pyplot as plt
from joblib import load
from src.model import ForwardSDE

def load_data(args, base_dir="."):
    data_pt = torch.load(os.path.join(base_dir, args.data_path))
    x = data_pt['xp']
    y = data_pt['y']
    args.x_dim = x[0].shape[-1]
    return x, y, args

config = SimpleNamespace(**torch.load('RESULTS/seed1/config.pt'))
x, y, config = load_data(config)
model = ForwardSDE(config)
model.load_state_dict(torch.load('RESULTS/seed1/train.best.pt')['model_state_dict'])
um = load('data/um_transformer.joblib')
sample_num = 1500
XX = []
tt = []
for ii, t in enumerate(y):
    N = x[ii].shape[0]
    if ii == 0:
        index0 = np.random.choice(range(N), sample_num, replace=False)
    Index = np.random.choice(range(N), sample_num, replace=False)
    X = x[ii][Index]
    t = (((torch.ones(sample_num)) * t).unsqueeze(1))
    XX.append(X)
    tt.append(t)
tt = torch.cat(tt)
x_all = torch.cat(XX)
x_all_2dim = um.transform(x_all.cpu().numpy())
y_ts = [np.float64(y[ts_i]) for ts_i in range(len(y))]
x_pred, _ = model(y_ts, x[0][index0, :], XX[-1])
x_pred = torch.cat([x_pred[ixs] for ixs in range(x_pred.shape[0])], dim=0)
x_all_2dim_pred = um.transform(x_pred.detach().cpu().numpy())

# 创建左右两个子图
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# 左图：真实值散点图（按时间 tt 着色）
sc1 = ax1.scatter(
    x=np.asarray(x_all_2dim[:, 0]),
    y=np.asarray(x_all_2dim[:, 1]),
    c=tt,  # 使用 tt 作为颜色映射
    cmap='viridis',  # 选择颜色映射（如 'viridis', 'plasma', 'cool'）
    marker='*',
    s=90,
    edgecolors='white',
    linewidths=0.01,
    alpha=0.95,
)
ax1.set_title("True Values (Colored by Time)")
ax1.grid(True, linestyle='--', alpha=0.4)

# 右图：预测值散点图（按时间 tt 着色）
sc2 = ax2.scatter(
    x=np.asarray(x_all_2dim_pred[:, 0]),
    y=np.asarray(x_all_2dim_pred[:, 1]),
    c=tt,  # 使用相同的 tt 作为颜色映射
    cmap='viridis',
    marker='*',
    s=90,
    edgecolors='white',
    linewidths=0.01,
    alpha=0.95,
)
ax2.set_title("Predicted Values (Colored by Time)")
ax2.grid(True, linestyle='--', alpha=0.4)


plt.tight_layout()
plt.savefig('scatter.png', dpi=800, bbox_inches='tight')
plt.show()
