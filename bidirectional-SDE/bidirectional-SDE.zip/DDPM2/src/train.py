import ot
import torch
from torch import optim, nn
import numpy as np
from geomloss import SamplesLoss
import tqdm
from src.model import ForwardSDE
import os
from src.config_Veres import load_data

# 数据采样函数
def p_samp(p, num_samp, w=None):
    repflag = p.shape[0] < num_samp
    p_sub = np.random.choice(p.shape[0], size=num_samp, replace=repflag)
    if w is None:
        w_ = torch.ones(len(p_sub))
    else:
        w_ = w[p_sub].clone()
    w_ = w_ / w_.sum()
    return p[p_sub, :].clone(), w_

def init_device(args):
    args.cuda = args.use_cuda and torch.cuda.is_available()
    device = torch.device('cuda:{}'.format(args.device) if args.cuda else 'cpu')
    return device

# ---- loss
class OTLoss():

    def __init__(self, config, device):
        self.ot_solver = SamplesLoss("sinkhorn", p=2, blur=config.sinkhorn_blur,
                                     scaling=config.sinkhorn_scaling, debias=True)
        self.device = device

    def __call__(self, a_i, x_i, b_j, y_j, requires_grad=True):
        a_i = a_i.to(self.device)
        x_i = x_i.to(self.device)
        b_j = b_j.to(self.device)
        y_j = y_j.to(self.device)

        if requires_grad:
            a_i.requires_grad_()
            x_i.requires_grad_()
            b_j.requires_grad_()

        loss_xy = self.ot_solver(a_i, x_i, b_j, y_j)
        return loss_xy

class OT_loss1(nn.Module):
    _valid = 'emd sinkhorn sinkhorn_knopp_unbalanced'.split()
    def __init__(self, which='emd', use_cuda=True):
        if which not in self._valid:
            raise ValueError(f'{which} not known ({self._valid})')
        self.which = which
        self.use_cuda = use_cuda
    def __call__(self, mu, source, nu, target, device='cuda', sigma=None, use_cuda=None):
        if use_cuda is None:
            use_cuda = self.use_cuda
        if not isinstance(mu, torch.Tensor):
            mu = torch.tensor(mu, dtype=torch.float32)
        if not isinstance(nu, torch.Tensor):
            nu = torch.tensor(nu, dtype=torch.float32)
        if use_cuda:
            mu = mu.to(device)
            nu = nu.to(device)
            target = target.to(device)
        M = torch.cdist(source, target) ** 2
        if self.which == 'emd':
            pi = ot.emd(mu.detach().cpu().numpy(), nu.detach().cpu().numpy(), M.detach().cpu().numpy())
        elif self.which == 'sinkhorn':
            if sigma is None:
                raise ValueError('sigma must be provided for sinkhorn method')
            pi = ot.sinkhorn(mu, nu, M, sigma)
        elif self.which == 'sinkhorn_knopp_unbalanced':
            if sigma is None:
                raise ValueError('sigma must be provided for sinkhorn_knopp_unbalanced method')
            pi = ot.unbalanced.sinkhorn_knopp_unbalanced(mu.detach().cpu().numpy(), nu.detach().cpu().numpy(),
                                                         M.detach().cpu().numpy(), sigma, sigma)
        else:
            raise ValueError(f'{self.which} not known ({self._valid})')

        if isinstance(pi, np.ndarray):
            pi = torch.tensor(pi, dtype=torch.float32)
        elif isinstance(pi, torch.Tensor):
            pi = pi.clone().detach()
        pi = pi.to(device) if use_cuda else pi
        M = M.to(pi.device)
        loss = torch.sum(pi * M)
        return loss

def run_leaveout(args,initial_config):
    # ---- initialize
    device = init_device(args)
    args.task = 'leaveout'
    Train_ts = args.train_t

    args.train_t = list(sorted(set(Train_ts)))
    print('--------------------------------------------')
    print('----------train_t=', args.train_t)
    print('--------------------------------------------')

    config = initial_config(args)
    x, y, config = load_data(config)

    if os.path.exists(os.path.join(config.out_dir, 'train.epoch_003000.pt')):
        print(os.path.join(config.out_dir, 'train.epoch_003000.pt'), ' exists. Skipping.')

    else:

        model = ForwardSDE(config)
        model.to(device)
        model.zero_grad()
        model_dict = model.state_dict()
        print(model)

        pretrained_dict = torch.load('RESULTS/seed0/train.best.pt', map_location=device)['model_state_dict']
        # 1. For self.net - load weights from "_func.net."
        net_weights = {k.replace("_func.net.", "net.net."): v
                       for k, v in pretrained_dict.items()
                       if k.startswith("_func.net.")}
        pretrained_dict = torch.load('RESULTS/seed1/train.best.pt', map_location=device)['model_state_dict']
        # 2. For self._func.net1 - load weights from "_func.net1."
        net1_weights = {k: v
                        for k, v in pretrained_dict.items()
                        if k.startswith("_func.net1.")}
        # Update model_dict with both sets of weights
        model_dict.update(net_weights)
        model_dict.update(net1_weights)
        # Load the updated weights into the model
        model.load_state_dict(model_dict)

        loss = OTLoss(config, device)
        # loss = OT_loss1()
        torch.save(config.__dict__, config.config_pt)

        optimizer = optim.Adam(list(model.parameters()), lr=config.train_lr)
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.5)
        optimizer.zero_grad()
        pbar = tqdm.tqdm(range(config.train_epochs))
        best_train_loss_xy = np.inf

        with open(config.train_log, 'w') as log_handle:

            for epoch in pbar:

                losses_xy_z = []
                losses_xy_f = []
                losses_xy_zf = []
                config.train_epoch = epoch
                dat_prev_0 = x[config.start_t]
                x_i_0, a_i_0 = p_samp(dat_prev_0, int(dat_prev_0.shape[0] * args.train_batch))
                x_i_0 = x_i_0.to(device)

                dat_prev_1 = x[-1]
                x_i_1, a_i_1 = p_samp(dat_prev_1, int(dat_prev_1.shape[0] * args.train_batch))
                x_i_1 = x_i_1.to(device)

                ts = [0] + Train_ts
                y_ts = [np.float64(y[ts_i]) for ts_i in ts]
                x_r_s_z, x_r_s_f = model(y_ts, x_i_0, x_i_1)

                for i, j in zip(config.train_t, [6, 5, 4, 3, 2, 1, 0]):
                    position = Train_ts.index(i)

                    dat_cur = x[i]
                    y_j, b_j = p_samp(dat_cur, int(dat_cur.shape[0] * args.train_batch))
                    loss_xy_z = loss(a_i_0, x_r_s_z[position + 1], b_j, y_j)
                    dat_cur = x[j]
                    y_j, b_j = p_samp(dat_cur, int(dat_cur.shape[0] * args.train_batch))
                    loss_xy_f = loss(a_i_1, x_r_s_f[position + 1], b_j, y_j)
                    x_r_s_f_f = torch.flip(x_r_s_f, dims=[0])
                    loss_xy_zf = loss(a_i_0, x_r_s_z[position + 1], a_i_1, x_r_s_f_f[position + 1])

                    losses_xy_z.append(loss_xy_z.item())
                    losses_xy_f.append(loss_xy_f.item())
                    losses_xy_zf.append(loss_xy_zf.item())
                    loss_xy = loss_xy_z + loss_xy_f # + loss_xy_zf
                    loss_xy.backward(retain_graph=True)

                train_loss_xy_z = np.mean(losses_xy_z)
                train_loss_xy_f = np.mean(losses_xy_f)
                train_loss_xy_zf = np.mean(losses_xy_zf)
                if config.train_clip > 0:
                    torch.nn.utils.clip_grad_norm_(model.parameters(), config.train_clip)
                optimizer.step()
                scheduler.step()
                model.zero_grad()

                # report
                desc = "[train] {}".format(epoch + 1)
                desc += " {:.6f}".format(train_loss_xy_z)
                desc += " {:.6f}".format(train_loss_xy_f)
                desc += " {:.6f}".format(train_loss_xy_zf)
                desc += " {:.6f}".format(best_train_loss_xy)
                pbar.set_description(desc)
                log_handle.write(desc + '\n')
                log_handle.flush()

                if train_loss_xy_z < best_train_loss_xy:
                    best_train_loss_xy = train_loss_xy_z
                    torch.save({
                        'model_state_dict': model.state_dict(),
                        'epoch': config.train_epoch + 1,
                    }, config.train_pt.format('best'))


    return config










