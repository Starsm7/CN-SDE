import torch
from collections import OrderedDict
from torch import nn
import src.sde as sde





# LipSwish 激活函数
class LipSwish(torch.nn.Module):
    def forward(self, x):
        return 0.909 * torch.nn.functional.silu(x)

class MLP(torch.nn.Module):
    def __init__(self, input_dim, out_dim, hidden_dim, num_layers, tanh):
        super().__init__()

        model = [torch.nn.Linear(input_dim, hidden_dim), LipSwish()]
        for _ in range(num_layers - 1):
            model.append(torch.nn.Linear(hidden_dim, hidden_dim))
            model.append(LipSwish())
        model.append(torch.nn.Linear(hidden_dim, out_dim))
        if tanh:
            model.append(torch.nn.Tanh())
        self._model = torch.nn.Sequential(*model)

    def forward(self, x):
        return self._model(x)


# 负责计算 SDE 中的漂移项（drift）和扩散项（diffusion）
class AutoGenerator(nn.Module):

    def __init__(self, config):
        super(AutoGenerator, self).__init__()

        self.dim = config.x_dim
        self.k_dims = config.k_dims
        self.layers = config.layers
        self.sigma_const = config.sigma_const

        self.activation = config.activation
        self.act = nn.Softplus
        
        self.net_ = []
        for i in range(self.layers): 
            if i == 0: 
                self.net_.append(('linear{}'.format(i+1), nn.Linear(self.dim+1, self.k_dims[i]))) 
            else: 
                self.net_.append(('linear{}'.format(i+1), nn.Linear(self.k_dims[i-1], self.k_dims[i]))) 
            self.net_.append(('{}{}'.format(self.activation, i+1), self.act()))
        self.net_.append(('linear', nn.Linear(self.k_dims[-1], self.dim, bias = False)))
        self.net_ = OrderedDict(self.net_)
        self.net = nn.Sequential(self.net_)

        self.noise_type = 'diagonal'
        self.sde_type = "ito"
        self.register_buffer('sigma', torch.as_tensor(self.sigma_const))
        self.sigma = self.sigma.repeat(self.dim).unsqueeze(0)

    def _pot(self, xt):
        xt = xt.requires_grad_()
        pot = self.net(xt)
        return pot

    def f(self, t, x):
        t = (((torch.ones(x.shape[0]).to(x.device)) * t).unsqueeze(1))
        xt = torch.cat([x, t], dim=1)
        pot = self._pot(xt)
        return pot

    def g(self, t, x):
        g = self.sigma.repeat(x.shape[0], 1)
        return g




class ForwardSDE(torch.nn.Module):
    def __init__(self, config):
        super(ForwardSDE, self).__init__()

        self._func = AutoGenerator(config)

    def forward(self, ts, x_0):
        x_r_s = sde.sdeint_adjoint(self._func, x_0, ts, method='euler', dt=0.1, dt_min=0.0001,
                                     adjoint_method='euler', names={'drift': 'f', 'diffusion': 'g'} )
        return x_r_s


