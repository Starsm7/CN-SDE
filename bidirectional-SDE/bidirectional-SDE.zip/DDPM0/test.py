import os
import random
from types import SimpleNamespace
import numpy as np
import torch
from src.config_Veres import init_config
from src.evaluation import evaluate_fit_leaveout
import warnings
warnings.filterwarnings("ignore")
def seed_everything(seed=11):
    random.seed(seed)
    np.random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':16:8'
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)

seed_everything(967)

path = f"RESULTS/seed0/config.pt"
config_train = SimpleNamespace(**torch.load(path))
evaluate_fit_leaveout(config_train, init_config, leaveouts=[7], use_loss='emd')
